﻿namespace EShopOnAbp.OrderingService.Application.Contracts
{
  public class Class1
  {

  }
}
