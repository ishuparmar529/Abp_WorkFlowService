﻿namespace EShopOnAbp.WorkflowService.HttpApi.Client
{
  public class Class1
  {

  }
}
